---
name: Judicial Custody Architecture
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#006a63'
  on-secondary: '#ffffff'
  secondary-container: '#99efe5'
  on-secondary-container: '#006f67'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#00164e'
  on-tertiary-container: '#6780d3'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#9cf2e8'
  secondary-fixed-dim: '#80d5cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#00504a'
  tertiary-fixed: '#dce1ff'
  tertiary-fixed-dim: '#b6c4ff'
  on-tertiary-fixed: '#00164e'
  on-tertiary-fixed-variant: '#264191'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-code-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-code-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  label-meta-caps:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-xxs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-base: 1rem
  space-lg: 1.25rem
  space-xl: 1.5rem
  space-2xl: 2rem
  gutter-table: 0.75rem
  margin-screen: 1.5rem
---

## Brand & Style
The design system embodies the solemnity, indisputable authority, and uncompromising integrity required by the justice ecosystem—serving law enforcement investigators, forensic specialists, public prosecutors, and presiding judges. 

The aesthetic is anchored in **Corporate / Modern High-Assurance Technical Realism**. It eliminates decorative ambiguity, frivolous curves, and non-functional embellishments. Instead, it prioritizes absolute visual clarity, structured data density, unambiguous hierarchy, and strict auditability. Interfaces must evoke quiet authority, institutional trust, and forensic precision. Every interaction reflects chain-of-custody finality: actions are logged, immutable, and validated against cryptographic state.

## Colors
The system employs a disciplined, high-contrast palette calibrated for enterprise judicial workflows and long operating sessions under varied ambient light conditions.

### Architectural Palette
- **Primary Navy (`#0F172A`)**: Represents the rule of law, institutional authority, and final judgment. Serves as the primary surface base for sidebars, persistent headers, and deep visual anchors.
- **Surface Accents & Telemetry (`#0F766E`)**: Distinctive steel teal reserved for structural metadata, node confirmation metrics, cryptographic validations, and active ledger filters.
- **Judicial Accent (`#1E3A8A`)**: Deep royal indigo utilized for active primary commitments, case assignment indicators, and high-level judicial operations.
- **Structural Neutrals (`#F8FAFC` to `#0F172A`)**: Clean slate neutrals calibrated to deliver maximum legible separation across high-density evidence grids, split-pane document comparisons, and ledger logs.

### Semantic Chain-of-Custody Tokens
Color is never used as the single identifier of system state. Semantic tokens are accompanied by mandatory tabular micro-labels and geometric icon signals:
- **Verified / Sealed Consensus (`#059669` / Surface: `#ECFDF5`, Border: `#A7F3D0`)**: Signifies verified Merkle tree proof, valid cryptographic signatures, and distributed block consensus.
- **Tamper / Security Breach (`#DC2626` / Surface: `#FEF2F2`, Border: `#FECACA`)**: Signifies SHA-256 hash discrepancies, signature invalidation, or unauthorized access attempts.
- **Pending / Node Sync (`#D97706` / Surface: `#FFFBEB`, Border: `#FDE68A`)**: Indicates consensus in flight, pending judicial signatures, or unconfirmed ledger transmittals.
- **Evidentiary Restricted (`#475569` / Surface: `#F1F5F9`, Border: `#CBD5E1`)**: Used for sealed records, ex-parte motions, and permission-gated documents.

## Typography
Typography enforces structural rigor and fast scannability across dense forensic tables and legal dockets.

### Dual Typeface Architecture
1. **Primary Workhorse (Inter)**: Handles all narrative, interface headers, tabular grids, form controls, and judicial metadata. Inter provides superior vertical balance and unambiguous distinction between glyphs (e.g., `1`, `l`, `I`).
2. **Cryptographic Engine (JetBrains Mono)**: Dedicated to machine-verified values including SHA-256 digests, block hashes, digital signature fingerprints, timestamps (ISO 8601), and Case/FIR docket reference numbers.

### Typographic Rules
- All numeric figures in evidentiary lists, data tables, and telemetry grids must render using OpenType tabular figures (`font-variant-numeric: tabular-nums`).
- Metadata headers, clearance levels, and custody statuses must leverage `label-meta-caps` with strict uppercase styling and `0.08em` tracking.
- Cryptographic hashes must truncate symmetrically (e.g., `0x7F4B…9C21`) in constrained interfaces, expanding to full `label-code-sm` format on explicit interaction or audit export.

## Layout & Spacing
The layout system is built on a high-density 4px/8px modular grid tailored for data-dense split-view and multi-column institutional software.

### Layout Model
- **Structural Multi-Panel Grid**: The desktop interface utilizes a fixed-width global primary navigation pane (260px expanded, 64px collapsed), an optional secondary case-explorer tree (300px), a fluid central evidence workspace, and a contextual audit rail (340px collapsible).
- **Persistent Case-Context Header**: Fixed 52px high-utility bar running across the top of active workspaces containing permanent FIR/Docket numbers, legal classification flags, and distributed sync metrics.
- **Data Table Spacing**: Compact 36px table row heights for dense forensic catalogs; standard 44px rows when housing interactive cryptographic validation triggers and multi-badge signatures.

### Breakpoints & Adaptations
- **Desktop Wide (1440px+)**: All 3 panels visible simultaneously (Navigation, Document Dossier, Live Blockchain Verification Ledger).
- **Desktop Standard (1024px – 1439px)**: Verification ledger transitions into an off-canvas drawer triggered via contextual custody badges.
- **Tablet / In-Court Mobile (Below 1024px)**: Secondary navigation collapses into icon rail; workspace reflows to a single unified column with sticky bottom audit actions.

## Elevation & Depth
To preserve forensic seriousness and avoid visual noise, the design system rejects skeuomorphic heavy drop shadows, decorative lighting gradients, and floating blur planes. Depth is rendered strictly through **Tonal Structural Layers** and **Crisp Outlines**.

### Elevation Hierarchy
1. **Level 0 (Canvas Base - `#F8FAFC`)**: The fundamental background canvas where workspaces and documents sit.
2. **Level 1 (Card & Panel Surfaces - `#FFFFFF`)**: Document containers, ledger inspection cards, and input panels. Delineated exclusively by a solid 1px border (`#E2E8F0`), with no ambient shadow.
3. **Level 2 (Persistent Rails & Sticky Headers - `#FFFFFF` or `#0F172A`)**: Case-context strips, toolbars, and tabular headers. Delineated by a directional bottom or right border (`#CBD5E1` in light mode, `#1E293B` in dark navy structural areas) and an ultra-subtle grounding shadow: `0 1px 2px 0 rgba(15, 23, 42, 0.05)`.
4. **Level 3 (Modal Overlays & Cryptographic Proof Drawers - `#FFFFFF`)**: Security confirmation prompts, signature approval modals, and raw hash inspector dialogs. Paired with a precise structural shadow: `0 10px 15px -3px rgba(15, 23, 42, 0.1), 0 4px 6px -4px rgba(15, 23, 42, 0.05)` and a 1px border (`#94A3B8`).

## Shapes
The shape language conveys structural permanence, technical precision, and legal solemnity. 

### Geometric Rules
- **Corner Radius**: Standardized to `Soft` (4px / `0.25rem`). Buttons, text fields, evidentiary cards, status badges, and table containers adhere strictly to this limit.
- **Modals and Flyout Sheets**: Maximize corner radius at 8px (`0.5rem`). Circular or pill shapes (`9999px`) are forbidden across all core UI controls to eliminate casual or playful connotations.
- **Indicator Dots**: Minimal 6px solid circles are permitted strictly for real-time node connectivity and consensus telemetry indicators.
- **Border Weight**: Uniform 1px solid stroke across all interactive and structural borders. Focus indicators use an exact 2px outline offset by 2px (`outline: 2px solid #0F766E; outline-offset: 2px`).

## Components

### Buttons & Cryptographic Actions
- **Primary Action (Commit / Seal Document)**: Background `#0F172A`, text `#FFFFFF`, 4px radius, 36px height (desktop dense), horizontal padding 16px. Font weight 600. Active state `#1E293B`.
- **Secondary / Verification (Verify Ledger)**: Background `#FFFFFF`, border 1px solid `#CBD5E1`, text `#0F172A`. Hover: `#F1F5F9`, border `#94A3B8`.
- **Destructive / Flag Tamper**: Background `#DC2626`, text `#FFFFFF`. Hover: `#B91C1C`.
- **Permission-Gated State**: Background `#F1F5F9`, border 1px dashed `#CBD5E1`, text `#94A3B8`. Contains a leading 14px padlock icon. Hover presents a persistentTooltip displaying: *"Cryptographic Authorization Required: Role [Judicial Magistrate] or PKI Multi-Sig Clear"* with cursor set to `not-allowed`.

### Custody Status Badges
Every custody badge must consist of three bound elements:
1. **Container**: Fixed 22px height, 4px radius, 1px perimeter border.
2. **Leading SVG Status Glyphs**:
   - Confirmed: Shield check icon.
   - Pending: Segmented clock/node icon.
   - Tamper Alert: Equilateral warning triangle with exclamation mark.
3. **Monospaced Micro-Text**: JetBrains Mono 11px uppercase string specifying state and proof metrics (e.g., `SEALED [12/12 NODES]`, `HASH MATCH INVALID`, `TX PENDING BLOCK #41029`).

### Persistent Case-Context Header Bar
- Anchored directly beneath global browser framing, fixed height 52px, background `#0F172A`, border-bottom 1px solid `#1E293B`.
- Contains:
  - FIR / Court Docket ID in `JetBrains Mono` bold (`#F8FAFC`).
  - Clearance Tag (e.g., `RESTRICTED / EX-PARTE`) in high-contrast inverted badge.
  - Active Jurisdictional Bench and Assigned Investigating Officer/Judge name.
  - Node Health Heartbeat: Pulse indicator showcasing active ledger network sync state (`0.04s latency`).

### Dense Evidentiary Data Grids
- **Header**: Height 32px, background `#F1F5F9`, border-bottom 1px solid `#CBD5E1`. Labels use `label-meta-caps` in color `#475569`.
- **Rows**: Alternating background or pure `#FFFFFF` with `#E2E8F0` row dividers. Cells use `Inter` 13px with tabular figures.
- **Hover**: Immediate `#F8FAFC` row highlight with visible quick-action bar pinning hash verification and timeline audit icons to the right cell edge.

### Cryptographic Hash Snippets & Inspection Cells
- Hashes are rendered in `label-code-sm` with background `#F1F5F9`, border 1px solid `#E2E8F0`, padding 2px 6px, and 4px radius.
- Clicking automatically copies the full 64-character hex sequence to clipboard while showing a transient 2-second inline badge confirmation: `HASH COPIED [SHA-256]`.

### Form Controls & Evidence Inputs
- **Inputs**: 36px height, background `#FFFFFF`, border 1px solid `#CBD5E1`, 4px radius, text 13px. Focus states replace border with 1px `#0F766E` and apply a crisp 2px teal focus ring (`rgba(15, 118, 110, 0.2)`).
- **Read-Only / Evidentiary Sealed Inputs**: Distinct visual treatment using `#F8FAFC` surface, `#64748B` text, and a trailing lock badge signifying that the field has been committed to the immutable chain.